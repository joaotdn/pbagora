<?php
__('Auto Thickbox', 'auto-thickbox');
__('Automatically enables thickbox on thumbnail images (i.e. opens the images in a fancy pop-up).', 'auto-thickbox');
__('Next &gt;', 'auto-thickbox');
__('&lt; Prev', 'auto-thickbox');
__('Image', 'auto-thickbox');
__('of', 'auto-thickbox');
__('Close', 'auto-thickbox');
?>